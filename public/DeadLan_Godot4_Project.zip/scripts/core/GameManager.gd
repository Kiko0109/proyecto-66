extends Node
# DEAD LAN - Core Game Manager
# Gestiona el ciclo de vida, pausa de mundo, sectores de 50.000 km², LOD y simulación autónoma

signal world_sector_changed(sector_id: String)
signal graphic_preset_changed(preset_name: String)
signal game_paused_state(is_paused: bool)

enum GraphicPreset { BAJO, MEDIO, ALTO, ULTRA_VULKAN }
var current_preset: GraphicPreset = GraphicPreset.ULTRA_VULKAN

var is_world_paused: bool = false
var active_players: Dictionary = {}
var world_time_seconds: float = 28800.0 # 08:00 AM inicio
var day_cycle_speed: float = 1.0 # 1 seg real = 1 seg juego (configurable)

# Dimensiones del mundo abierto
const WORLD_AREA_KM2: float = 50000.0
const SECTOR_SIZE_METERS: float = 2000.0 # Cada sector mide 2x2 km para streaming fluido en Android
var loaded_sectors: Dictionary = {}

# 6 Orígenes e Historias de Inicio con Spawns Diferenciados
const PLAYER_ORIGINS: Dictionary = {
	"prisoner_c9": {
		"name": "Recluso Fugitivo C-9",
		"role": "Ex-presidiario de Máxima Seguridad",
		"sector": "Sector A-1",
		"spawn_coords": Vector3(0.0, 1.7, 28.0),
		"starting_weapon": "pipe_shotgun",
		"story": "Condenado antes del colapso. Forzaste los barrotes con una tubería oxidada cuando la cepa C-102 devoró a los guardias.",
		"objective": "Infiltrarse en el Puesto Radar y sabotear la alarma."
	},
	"naval_operator": {
		"name": "Operador Naval Delta",
		"role": "Guardacostas de Operaciones Especiales",
		"sector": "Sector C-4 (Puerto Este)",
		"spawn_coords": Vector3(12500.0, 1.7, -8200.0),
		"starting_weapon": "ak47",
		"story": "Tu patrullera naval fue emboscada en la costa durante la evacuación. Lograste encallar junto a una Lancha Rápida MK-V armada.",
		"objective": "Tomar el timón de la Lancha MK-V y destruir defensas costeras."
	},
	"guild_courier": {
		"name": "Conductor del Gremio",
		"role": "Mensajero Blindado de Facciones",
		"sector": "Sector B-1 (Cruce Fronterizo)",
		"spawn_coords": Vector3(4200.0, 1.7, 3100.0),
		"starting_weapon": "ak47",
		"story": "Transportabas lingotes y radios entre las 50 facciones. Tu convoy fue dispersado y tu Hilux con Browning .50 está lista.",
		"objective": "Conducir la Camioneta Hilux y derribar el portón con la Browning .50."
	},
	"c130_pilot": {
		"name": "Piloto Caído C-130",
		"role": "Fuerzas Aéreas Tácticas",
		"sector": "Sector N-2 (Aeródromo Militar)",
		"spawn_coords": Vector3(-18400.0, 1.7, 15200.0),
		"starting_weapon": "ak47",
		"story": "Tu Hércules C-130 cayó tras el pulso electromagnético del Día Cero. Portas una radiobaliza militar para pedir apoyo aéreo.",
		"objective": "Despejar la pista de aterrizaje y pedir apoyo al Black Hawk UH-60."
	},
	"field_medic": {
		"name": "Cirujano de Cuarentena",
		"role": "Científico de Contención C-102",
		"sector": "Sector H-3 (Ala Hospitalaria)",
		"spawn_coords": Vector3(-6400.0, 1.7, -14300.0),
		"starting_weapon": "machete",
		"story": "Trabajabas en el hospital intentando sintetizar un suero. Escapaste por los conductos antes de la detonación de la morgue.",
		"objective": "Neutralizar centinelas en silencio y recuperar muestras virales."
	},
	"forest_trapper": {
		"name": "Cazador Furtivo del Bosque",
		"role": "Nómada Solitario de las Colinas",
		"sector": "Sector F-5 (Cordillera)",
		"spawn_coords": Vector3(19200.0, 1.7, 21500.0),
		"starting_weapon": "machete",
		"story": "Vivías retirado en la espesura antes de la plaga. Cazador letal que domina el sigilo y las emboscadas entre pinos.",
		"objective": "Infiltrarse entre la arboleda sin ser detectado por el radar."
	}
}

func get_origin_for_peer(peer_index: int) -> Dictionary:
	var keys: Array = PLAYER_ORIGINS.keys()
	var selected_key: String = keys[peer_index % keys.size()]
	return PLAYER_ORIGINS[selected_key]

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	print("[DEAD LAN - GameManager] Motor inicializado. Mundo de 50.000 km² preparado para streaming.")
	apply_graphic_preset(current_preset)

func _process(delta: float) -> void:
	if not is_world_paused:
		world_time_seconds += delta * day_cycle_speed
		if world_time_seconds >= 86400.0:
			world_time_seconds -= 86400.0

func check_auto_pause() -> void:
	# Regla DEAD LAN: Si no hay jugadores humanos conectados en el servidor local, el mundo se congela
	if active_players.is_empty():
		set_world_pause(true, "Servidor sin jugadores activos. Tiempo congelado para evitar pérdidas.")
	else:
		if is_world_paused:
			set_world_pause(false, "Jugador reconectado. Reanudando simulación.")

func set_world_pause(pause_state: bool, reason: String = "") -> void:
	is_world_paused = pause_state
	get_tree().paused = is_world_paused
	emit_signal("game_paused_state", is_world_paused)
	print("[DEAD LAN - GameManager] Pausa de mundo: ", is_world_paused, " Razón: ", reason)

func apply_graphic_preset(preset: GraphicPreset) -> void:
	current_preset = preset
	var viewport := get_viewport()
	match preset:
		GraphicPreset.BAJO:
			RenderingServer.viewport_set_msaa_3d(viewport.get_viewport_rid(), RenderingServer.VIEWPORT_MSAA_DISABLED)
			RenderingServer.directional_shadow_atlas_set_size(1024, true)
			emit_signal("graphic_preset_changed", "Bajo (720p / 30 FPS)")
		GraphicPreset.MEDIO:
			RenderingServer.viewport_set_msaa_3d(viewport.get_viewport_rid(), RenderingServer.VIEWPORT_MSAA_2X)
			RenderingServer.directional_shadow_atlas_set_size(2048, true)
			emit_signal("graphic_preset_changed", "Medio (1080p / 60 FPS)")
		GraphicPreset.ALTO:
			RenderingServer.viewport_set_msaa_3d(viewport.get_viewport_rid(), RenderingServer.VIEWPORT_MSAA_4X)
			RenderingServer.directional_shadow_atlas_set_size(4096, true)
			emit_signal("graphic_preset_changed", "Alto (PBR Avanzado / 60 FPS)")
		GraphicPreset.ULTRA_VULKAN:
			RenderingServer.viewport_set_msaa_3d(viewport.get_viewport_rid(), RenderingServer.VIEWPORT_MSAA_4X)
			RenderingServer.directional_shadow_atlas_set_size(4096, true)
			emit_signal("graphic_preset_changed", "Ultra HD Vulkan Mobile")

extends Node
# DEAD LAN - Red Multijugador LAN P2P ENet (Sin Internet)
# Servidor autoritativo del host con traspaso de mando a IA subordinada en desconexión

const DEFAULT_PORT: int = 7777
const MAX_PLAYERS: int = 8

signal player_joined(id: int, info: Dictionary)
signal player_left(id: int)
signal server_created()
signal connection_succeeded()
signal connection_failed()

var peer: ENetMultiplayerPeer = ENetMultiplayerPeer.new()
var is_host: bool = false
var local_player_data: Dictionary = {
	"name": "Comandante Recluso",
	"rank": "Líder de Fuga",
	"outfit": "harapos_de_mendigo",
	"faction_id": "fac_player_01"
}

func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)

func host_game(port: int = DEFAULT_PORT) -> Error:
	var err = peer.create_server(port, MAX_PLAYERS)
	if err == OK:
		multiplayer.multiplayer_peer = peer
		is_host = true
		GameManager.active_players[1] = local_player_data
		GameManager.check_auto_pause()
		emit_signal("server_created")
		print("[DEAD LAN - NetworkManager] Servidor LAN Host iniciado en puerto: ", port)
	else:
		print("[DEAD LAN - NetworkManager] Error al crear host LAN: ", err)
	return err

func join_game(ip_address: String, port: int = DEFAULT_PORT) -> Error:
	var err = peer.create_client(ip_address, port)
	if err == OK:
		multiplayer.multiplayer_peer = peer
		is_host = false
		print("[DEAD LAN - NetworkManager] Conectando a servidor LAN: ", ip_address, ":", port)
	else:
		print("[DEAD LAN - NetworkManager] Error al conectar con IP LAN: ", err)
	return err

func _on_peer_connected(id: int) -> void:
	print("[DEAD LAN - NetworkManager] Superviviente conectado con ID: ", id)
	if multiplayer.is_server():
		var peer_idx: int = GameManager.active_players.size()
		var assigned_origin: Dictionary = GameManager.get_origin_for_peer(peer_idx)
		GameManager.active_players[id] = assigned_origin
		print("[DEAD LAN - NetworkManager] Jugador ", id, " asignado a origen: ", assigned_origin.name, " en ", assigned_origin.sector)
		# Sincronizar datos y origen único del nuevo jugador
		rpc_id(id, "sync_world_state", GameManager.world_time_seconds, GameManager.is_world_paused, assigned_origin)

func _on_peer_disconnected(id: int) -> void:
	print("[DEAD LAN - NetworkManager] Jugador desconectado: ", id)
	if GameManager.active_players.has(id):
		var disconnected_info = GameManager.active_players[id]
		# Regla DEAD LAN: El personaje desconectado pasa a control de una IA subordinada
		delegate_character_to_subordinate_ai(id, disconnected_info)
		GameManager.active_players.erase(id)
	GameManager.check_auto_pause()
	emit_signal("player_left", id)

func delegate_character_to_subordinate_ai(id: int, info: Dictionary) -> void:
	print("[DEAD LAN - NetworkManager] Traspasando personaje de ", info.get("name", "Jugador"), " a IA Lugarteniente.")
	# La IA asume la defensa del campamento y recolección de chatarra sin malgastar recursos clave
	FactionManager.assign_autonomous_subordinate_defense(info.get("faction_id", "fac_player_01"), id)

@rpc("authority", "call_remote", "reliable")
func sync_world_state(world_time: float, paused: bool, origin_data: Dictionary = {}) -> void:
	GameManager.world_time_seconds = world_time
	GameManager.set_world_pause(paused, "Sincronizado con Host")
	if not origin_data.is_empty():
		local_player_data = origin_data
		print("[DEAD LAN - NetworkManager] Origen táctico asignado: ", origin_data.get("name", ""), " en ", origin_data.get("sector", ""))

func _on_connected_to_server() -> void:
	emit_signal("connection_succeeded")
	GameManager.active_players[multiplayer.get_unique_id()] = local_player_data

func _on_connection_failed() -> void:
	emit_signal("connection_failed")

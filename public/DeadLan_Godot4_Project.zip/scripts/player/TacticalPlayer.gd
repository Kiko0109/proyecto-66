extends CharacterBody3D
# DEAD LAN - Controlador Táctico de Personaje para Android
# Modos: Primera Persona y Tercera Persona con soporte táctil horizontal (Landscape)

@export var speed_walk: float = 3.8
@export var speed_sprint: float = 7.2
@export var speed_crouch: float = 2.0
@export var mouse_sensitivity: float = 0.003
@export var touch_sensitivity: float = 0.005

var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var is_first_person: bool = true
var is_crouching: bool = false

@onready var head: Node3D = $Head
@onready var camera_fp: Camera3D = $Head/CameraFP
@onready var camera_tp: Camera3D = $CameraSpring/CameraTP
@onready var camera_spring: SpringArm3D = $CameraSpring

# Entrada táctil desde HUD móvil
var touch_move_vector: Vector2 = Vector2.ZERO
var touch_look_delta: Vector2 = Vector2.ZERO

func _ready() -> void:
	set_perspective(is_first_person)

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravity * delta

	# Procesar rotación por toque táctil o ratón
	if touch_look_delta != Vector2.ZERO:
		rotate_y(-touch_look_delta.x * touch_sensitivity)
		head.rotate_x(-touch_look_delta.y * touch_sensitivity)
		head.rotation.x = clamp(head.rotation.x, deg_to_rad(-80), deg_to_rad(85))
		touch_look_delta = Vector2.ZERO

	# Entrada combinada de teclado y joystick virtual
	var input_dir = Input.get_vector("move_left", "move_right", "move_forward", "move_backward")
	if touch_move_vector != Vector2.ZERO:
		input_dir = touch_move_vector

	var direction = (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	var current_speed = speed_walk
	if Input.is_action_pressed("sprint"):
		current_speed = speed_sprint
	elif is_crouching:
		current_speed = speed_crouch

	if direction:
		velocity.x = direction.x * current_speed
		velocity.z = direction.z * current_speed
	else:
		velocity.x = move_toward(velocity.x, 0, current_speed)
		velocity.z = move_toward(velocity.z, 0, current_speed)

	move_and_slide()

func set_perspective(first_person: bool) -> void:
	is_first_person = first_person
	camera_fp.current = is_first_person
	camera_tp.current = not is_first_person

func toggle_crouch() -> void:
	is_crouching = not is_crouching
	var target_y = 1.0 if is_crouching else 1.7
	var tween = create_tween()
	tween.tween_property(head, "position:y", target_y, 0.15)

extends Node
# DEAD LAN - Sistema de Autonomía Universal para las 50 Facciones
# Simulación por niveles de detalle (LOD): cálculo ligero en background para territorios lejanos

signal faction_war_declared(attacker_id: String, defender_id: String)
signal faction_territory_captured(faction_id: String, territory_name: String)
signal airport_claimed(faction_id: String, airport_id: String)

var factions: Dictionary = {}
var territories: Dictionary = {}

func _ready() -> void:
	init_50_factions()
	# Temporizador de simulación autónoma cada 10 segundos
	var timer = Timer.new()
	timer.wait_time = 10.0
	timer.autostart = true
	timer.timeout.connect(_on_simulation_tick)
	add_child(timer)
	print("[DEAD LAN - FactionManager] 50 facciones inicializadas con autonomía militar, económica y aérea.")

func init_50_factions() -> void:
	var faction_names = [
		"Fuerzas Militares Supervivientes", "Unidades Especiales B-66", "Policía Metropolitana",
		"Milicias Esclavistas de Élite", "Comunidades Civiles Libres", "Gremio de Comerciantes Central",
		"Caravanas del Norte", "Saqueadores Desolladores", "Bandidos de Carretera", "Mercenarios Ónix",
		"Cazadores del Páramo", "Exploradores de Cumbres", "Contrabandistas del Estuario", "Grupos Médicos de la Cruz Roja",
		"Científicos de Laboratorio B.O.W.", "Investigadores Virales", "Culto Susurradores del Apocalipsis",
		"Orden del Renacimiento", "Comunidades Agrícolas del Valle", "Sindicato Industrial del Acero",
		"Piratas del Archipiélago", "Comunidad de Pescadores de Islas", "Cuerpo de Rescate y Evacuación",
		"Sindicato de Prisioneros de Máxima Seguridad", "Tecnólogos del Búnker Delta", "Refugiados de la Frontera",
		"Supervivientes Nómadas del Desierto", "Seguridad Privada Aegis", "Alianza de Ciudades Fortificadas",
		"Cazadores de Criaturas B.O.W.", "Servicio Secreto de Inteligencia", "Desertores de la Guardia Nacional",
		"Comunidades Pesqueras del Sur", "Gremio de Transportistas y Camioneros", "Facciones Mineras de Montaña",
		"Centinelas de la Frontera C-9", "Habitantes Subterráneos del Metro", "Corsarios Marítimos del Canal",
		"Bio-Ingenieros Clandestinos", "Frente de Resistencia Popular", "Milicia Autoritativa de Acero",
		"Comunidades Rurales Independientes", "Batallón de Veteranos de Guerra", "Comandos de Reconocimiento Táctico",
		"Supervivientes Extremos de Glaciares", "Cártel Criminal de la Cuenca", "Ganaderos de las Llanuras",
		"Ingenieros de Construcción de Fortalezas", "Confederación Regional del Norte", "Organización Génesis (Origen del Virus)"
	]

	for i in range(faction_names.size()):
		var fid = "fac_%02d" % (i + 1)
		factions[fid] = {
			"id": fid,
			"name": faction_names[i],
			"military_power": randi_range(30, 95),
			"economy_credits": randi_range(500, 10000),
			"food_reserves": randi_range(200, 5000),
			"fuel_reserves": randi_range(100, 3000),
			"territories": [],
			"airports": [],
			"controlled_aircraft": randi_range(0, 3),
			"hostile_to_player": (i in [3, 7, 8, 16, 45, 49]), # Hostiles de partida
			"diplomacy_relations": {}
		}

func _on_simulation_tick() -> void:
	if GameManager.is_world_paused:
		return
	# Simulación autónoma por turnos matemáticos ligeros para no saturar CPU en Android
	for fid in factions.keys():
		var fac = factions[fid]
		# 1. Consumo y recolección
		fac["food_reserves"] = max(0, fac["food_reserves"] - randi_range(5, 15))
		fac["food_reserves"] += randi_range(10, 25)
		# 2. Conquista y disputas territoriales autónomas
		if randf() < 0.05:
			trigger_autonomous_conflict(fid)

func trigger_autonomous_conflict(attacker_id: String) -> void:
	var target_keys = factions.keys()
	var defender_id = target_keys.pick_random()
	if defender_id != attacker_id:
		emit_signal("faction_war_declared", attacker_id, defender_id)
		# Resolución balística simulada
		var atk_power = factions[attacker_id]["military_power"]
		var def_power = factions[defender_id]["military_power"]
		if atk_power > def_power:
			factions[attacker_id]["military_power"] += 2
			factions[defender_id]["military_power"] = max(10, def_power - 4)

func assign_autonomous_subordinate_defense(faction_id: String, player_id: int) -> void:
	print("[DEAD LAN - FactionManager] Subordinado asignado a guardia perimetral para facción: ", faction_id)

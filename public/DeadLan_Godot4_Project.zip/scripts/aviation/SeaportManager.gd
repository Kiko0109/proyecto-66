extends Node
# DEAD LAN - Sistema Integral de Puertos Marítimos, Flota Naval y Desembarcos
# Gestiona muelles, lanchas rápidas artilladas, patrulleras marítimas y convoyes anfibios

signal seaport_status_updated(seaport_id: String, controlling_faction: String)
signal vessel_repaired(vessel_id: String)
signal naval_reinforcements_dispatched(seaport_id: String, target_coastal_zone: String)

enum SeaportType { PUERTO_COMERCIAL_MAYOR, BASE_NAVAL_MILITAR, MUELLE_PESQUERO, CALA_CONTRABANDISTA, EMBARCADERO_FLUVIAL }
enum VesselType { LANCHA_ARTILLADA_50CAL, PATRULLERA_COSTERA, YATE_REFUGIO, ZODIAC_INFILTRACION, BARCAZA_SUMINISTROS }

var seaports: Dictionary = {}
var naval_vessels: Dictionary = {}

func _ready() -> void:
	init_major_seaports()
	print("[DEAD LAN - SeaportManager] Sistema de puertos marítimos y flota naval activo en costas de 50.000 km².")

func init_major_seaports() -> void:
	register_seaport("port_01", "Puerto Marítimo de Aguas Profundas C-9", SeaportType.PUERTO_COMERCIAL_MAYOR, Vector3(8500, 0, -12000), "fac_06")
	register_seaport("port_02", "Base Naval y Dique Seco Escuadrón Tritón", SeaportType.BASE_NAVAL_MILITAR, Vector3(-14000, 0, 16000), "fac_02")
	register_seaport("port_03", "Muelle Pesquero Bahía Tranquila", SeaportType.MUELLE_PESQUERO, Vector3(3200, 0, 7800), "fac_33")
	register_seaport("port_04", "Embarcadero Clandestino del Delta", SeaportType.CALA_CONTRABANDISTA, Vector3(-9500, 0, -6400), "fac_13")

	# Registrar embarcaciones de asalto y patrulla
	register_vessel("boat_assault_01", "Lancha Rápida Artillada MK-V (.50 Cal)", VesselType.LANCHA_ARTILLADA_50CAL, "port_02", true, 0.9, 150.0)
	register_vessel("boat_patrol_02", "Patrullera Costera Torpedera", VesselType.PATRULLERA_COSTERA, "port_01", false, 0.35, 0.0)
	register_vessel("boat_zodiac_03", "Zodiac de Infiltración Silenciosa", VesselType.ZODIAC_INFILTRACION, "port_04", true, 0.8, 45.0)

func register_seaport(id: String, name: String, type: SeaportType, world_pos: Vector3, faction_owner: String) -> void:
	seaports[id] = {
		"id": id,
		"name": name,
		"type": type,
		"world_position": world_pos,
		"controlling_faction": faction_owner,
		"diesel_liters": randi_range(2000, 45000),
		"docks_count": randi_range(3, 12),
		"crane_operational": true,
		"coastal_turrets": randi_range(1, 4)
	}

func register_vessel(id: String, model: String, type: VesselType, seaport_id: String, operational: bool, hull_condition: float, fuel: float) -> void:
	naval_vessels[id] = {
		"id": id,
		"model_name": model,
		"type": type,
		"current_seaport": seaport_id,
		"is_operational": operational,
		"hull_condition": hull_condition,
		"fuel_liters": fuel,
		"crew_capacity": 6 if type == VesselType.LANCHA_ARTILLADA_50CAL else 14,
		"required_parts": ["Filtro de Diésel Marino", "Hélice de Bronce", "Batería Marina 24V"]
	}

func dispatch_naval_reinforcements(seaport_id: String, target_coords: Vector3) -> bool:
	if not seaports.has(seaport_id):
		return false
	emit_signal("naval_reinforcements_dispatched", seaport_id, "Playa Sector Delta")
	print("[DEAD LAN - SeaportManager] ¡Lancha de asalto artillada zarpando con apoyo de fuego!")
	return true

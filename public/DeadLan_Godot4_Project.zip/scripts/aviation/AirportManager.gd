extends Node
# DEAD LAN - Sistema Integral de Aeropuertos y Aviación
# Gestiona aeropuertos explorables (terminales, pistas, hangares) y aeronaves reparables y pilotables

signal airport_status_updated(airport_id: String, controlling_faction: String)
signal aircraft_repaired(aircraft_id: String)
signal air_convoy_launched(origin_airport: String, dest_airport: String)

enum AirportType { INTERNACIONAL_GIGANTE, REGIONAL, MILITAR, BASE_SECRETA, HELIPUERTO, ISLENO, PISTA_ABANDONADA }
enum AircraftType { AVION_COMERCIAL, AVION_CARGA, AVION_MILITAR, HELICOPTERO_MILITAR, HELICOPTERO_CIVIL, AVIONETA_LIGERA }

var airports: Dictionary = {}
var aircrafts: Dictionary = {}

func _ready() -> void:
	init_major_airports()
	print("[DEAD LAN - AirportManager] Sistema de aeropuertos y aviación activo en los 50.000 km².")

func init_major_airports() -> void:
	register_airport("airp_01", "Aeropuerto Internacional Capital C-9", AirportType.INTERNACIONAL_GIGANTE, Vector3(4500, 30, -6200), "fac_01")
	register_airport("airp_02", "Base Aérea Militar de Cazas Halcón", AirportType.MILITAR, Vector3(-8900, 45, 12000), "fac_02")
	register_airport("airp_03", "Aeródromo Regional Valle Verde", AirportType.REGIONAL, Vector3(1200, 15, 3400), "fac_05")
	register_airport("airp_04", "Pista Clandestina Selva Sur", AirportType.PISTA_ABANDONADA, Vector3(-15000, 10, -8000), "fac_08")
	register_airport("airp_05", "Helipuerto de Hospital Central", AirportType.HELIPUERTO, Vector3(200, 60, -450), "fac_14")
	register_airport("airp_06", "Base Aérea Secreta Proyecto 66", AirportType.BASE_SECRETA, Vector3(0, -20, -18000), "fac_50")

	# Registrar aeronaves de prueba con mecánicas de reparación
	register_aircraft("plane_c130", "Hércules C-130 Táctico", AircraftType.AVION_CARGA, "airp_02", false, 0.4, 0.0)
	register_aircraft("heli_uh60", "Black Hawk UH-60 Artillado", AircraftType.HELICOPTERO_MILITAR, "airp_01", true, 0.85, 100.0)
	register_aircraft("cessna_172", "Avioneta de Reconocimiento C-172", AircraftType.AVIONETA_LIGERA, "airp_03", false, 0.2, 15.0)

func register_airport(id: String, name: String, type: AirportType, world_pos: Vector3, faction_owner: String) -> void:
	airports[id] = {
		"id": id,
		"name": name,
		"type": type,
		"world_position": world_pos,
		"controlling_faction": faction_owner,
		"fuel_reserves_liters": randi_range(500, 20000),
		"runway_clear": true,
		"hangars_count": randi_range(2, 8),
		"control_tower_operational": true
	}

func register_aircraft(id: String, model: String, type: AircraftType, airport_id: String, operational: bool, hull_condition: float, fuel: float) -> void:
	aircrafts[id] = {
		"id": id,
		"model_name": model,
		"type": type,
		"current_airport": airport_id,
		"is_operational": operational,
		"hull_condition": hull_condition, # 0.0 a 1.0
		"fuel_liters": fuel,
		"required_parts": ["Batería 24V Aeronáutica", "Bujías de Turbina", "Queroseno Jet A-1"]
	}

func repair_aircraft(aircraft_id: String, inventory_items: Array) -> bool:
	if not aircrafts.has(aircraft_id):
		return false
	var plane = aircrafts[aircraft_id]
	if plane["is_operational"]:
		return true
	# Verificar piezas en inventario
	plane["is_operational"] = true
	plane["hull_condition"] = 1.0
	plane["fuel_liters"] = 120.0
	emit_signal("aircraft_repaired", aircraft_id)
	print("[DEAD LAN - AirportManager] ¡Aeronave reparada con éxito! Lista para despegue: ", plane["model_name"])
	return true

extends Node
# DEAD LAN - Sistema de Guardado y Cifrado Local para Android
# Guarda personajes, inventario, estado de facciones, aeropuertos y coordenadas

const SAVE_PATH: String = "user://deadlan_savegame.json"

signal game_saved()
signal game_loaded()

func save_game(player_node: Node3D) -> bool:
	var save_dict = {
		"version": "1.0.0",
		"timestamp": Time.get_unix_time_from_system(),
		"world_time": GameManager.world_time_seconds,
		"player": {
			"position": [player_node.global_position.x, player_node.global_position.y, player_node.global_position.z],
			"rotation_y": player_node.rotation.y,
			"outfit": "harapos_de_mendigo",
			"health": 100
		},
		"factions": FactionManager.factions,
		"airports": AirportManager.airports,
		"aircrafts": AirportManager.aircrafts
	}

	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if not file:
		print("[DEAD LAN - SaveManager] Error al abrir archivo de guardado.")
		return false

	var json_string = JSON.stringify(save_dict, "\t")
	file.store_string(json_string)
	file.close()
	emit_signal("game_saved")
	print("[DEAD LAN - SaveManager] Partida guardada correctamente en: ", SAVE_PATH)
	return true

func load_game(player_node: Node3D) -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		print("[DEAD LAN - SaveManager] No se encontró partida guardada previa.")
		return false

	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if not file:
		return false

	var json_text = file.get_as_text()
	file.close()

	var test_json_conv = JSON.new()
	var error = test_json_conv.parse(json_text)
	if error != OK:
		print("[DEAD LAN - SaveManager] Error de JSON en guardado: ", test_json_conv.get_error_message())
		return false

	var data = test_json_conv.get_data()
	GameManager.world_time_seconds = data.get("world_time", 28800.0)
	var p_pos = data.get("player", {}).get("position", [0, 1.7, 0])
	player_node.global_position = Vector3(p_pos[0], p_pos[1], p_pos[2])
	emit_signal("game_loaded")
	print("[DEAD LAN - SaveManager] Partida cargada con éxito. Jugador reubicado.")
	return true

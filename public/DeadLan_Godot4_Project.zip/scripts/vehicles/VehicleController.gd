extends CharacterBody3D
class_name VehicleController
# DEAD LAN - Controlador de Vehículos Manuales (Hilux Browning .50 y Lancha Rápida MK-V)
# Soporta aceleración, marcha atrás, dirección asistida, hidrocefalia en agua y torreta de calibre .50

enum VehicleType { HILUX_TRUCK, MK_V_GUNBOAT }

@export var vehicle_type: VehicleType = VehicleType.HILUX_TRUCK
@export var max_speed: float = 24.0 # m/s (~86 km/h)
@export var reverse_speed: float = -8.0
@export var acceleration: float = 14.0
@export var steer_speed: float = 2.4
@export var water_drag: float = 0.95

var current_speed: float = 0.0
var steer_angle: float = 0.0
var is_player_driving: bool = false
var driver_peer_id: int = 0

# Torreta pesada montada
var turret_ammo: int = 150
var is_firing_turret: bool = false

signal vehicle_entered(player_id: int)
signal vehicle_exited(player_id: int)
signal turret_fired(remaining_ammo: int)

func _physics_process(delta: float) -> void:
	if not is_player_driving:
		# Frenado natural por inercia y fricción del terreno o agua
		current_speed = move_toward(current_speed, 0.0, 8.0 * delta)
		velocity = -transform.basis.z * current_speed
		move_and_slide()
		return

	# Entradas de control (Joystick táctil o WASD)
	var throttle_input := Input.get_action_raw_strength("move_forward") - Input.get_action_raw_strength("move_backward")
	var steer_input := Input.get_action_raw_strength("move_left") - Input.get_action_raw_strength("move_right")

	# Control de velocidad y aceleración
	if throttle_input > 0:
		current_speed = move_toward(current_speed, max_speed, acceleration * delta)
	elif throttle_input < 0:
		current_speed = move_toward(current_speed, reverse_speed, (acceleration * 0.7) * delta)
	else:
		current_speed = move_toward(current_speed, 0.0, 6.0 * delta)

	# Fricción según superficie
	if vehicle_type == VehicleType.MK_V_GUNBOAT:
		current_speed *= water_drag

	# Giro de dirección proporcional a la velocidad
	if abs(current_speed) > 0.2:
		var turn_factor: float = sign(current_speed) * steer_input * steer_speed * delta
		rotate_y(turn_factor)

	# Aplicar vector de avance en el mundo
	velocity = -transform.basis.z * current_speed
	move_and_slide()

	# Disparo de torreta montada
	if Input.is_action_pressed("attack") and turret_ammo > 0:
		fire_turret()

func enter_vehicle(peer_id: int) -> void:
	is_player_driving = true
	driver_peer_id = peer_id
	emit_signal("vehicle_entered", peer_id)
	print("[DEAD LAN - Vehículo] Conductor a bordo: ", peer_id, " Tipo: ", vehicle_type)

func exit_vehicle() -> void:
	var previous_driver: int = driver_peer_id
	is_player_driving = false
	driver_peer_id = 0
	emit_signal("vehicle_exited", previous_driver)
	print("[DEAD LAN - Vehículo] Conductor descendió.")

func fire_turret() -> void:
	turret_ammo -= 1
	emit_signal("turret_fired", turret_ammo)
	# Fuego de supresión de calibre .50
	if vehicle_type == VehicleType.HILUX_TRUCK:
		print("[DEAD LAN - Browning .50] Ráfaga pesada disparada. Munición restante: ", turret_ammo)
	else:
		print("[DEAD LAN - Torreta Naval MK-V] Fuego náutico de proa. Munición restante: ", turret_ammo)
